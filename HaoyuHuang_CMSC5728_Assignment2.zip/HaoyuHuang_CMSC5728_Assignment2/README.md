# CMSC5728 Programming Assignment #2

You just need to run the python file `final_visual.py`

```shell
python final_visual.py
```

And you can change the parameters within the file.